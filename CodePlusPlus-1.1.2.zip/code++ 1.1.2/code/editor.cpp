#define UNICODE
#define _UNICODE

#include <windows.h>
#include <commctrl.h>
#include <commdlg.h>
#include <richedit.h>

#include <string>
#include <fstream>
#include <iterator>
#include <algorithm>
#include <cwctype>

#pragma comment(lib, "Comdlg32.lib")
#pragma comment(lib, "Comctl32.lib")

// ============================================================
// ID
// ============================================================

#define ID_EDITOR       1001
#define ID_OUTPUT       1002
#define ID_STATUS       1003

#define ID_NEW_C        2001
#define ID_NEW_CPP      2002
#define ID_NEW_PY       2003
#define ID_NEW_TXT      2004
#define ID_NEW_ALL      2005

#define ID_OPEN         2010
#define ID_SAVE         2011
#define ID_SAVE_AS      2012
#define ID_EXIT         2013

#define ID_LANG_C       2101
#define ID_LANG_CPP     2102
#define ID_LANG_PY      2103
#define ID_LANG_TEXT    2104

#define ID_ENCODING_UTF8 2201
#define ID_ENCODING_ANSI 2202

#define ID_OUTPUT_CLEAR 2301
#define ID_ABOUT        2401

#define ID_TIMER_COLOR  3001


// ============================================================
// GLOBAL
// ============================================================

HWND g_main = nullptr;
HWND g_editor = nullptr;
HWND g_output = nullptr;
HWND g_status = nullptr;

HFONT g_editorFont = nullptr;
HFONT g_outputFont = nullptr;

HICON g_icon = nullptr;

std::wstring g_file;
std::wstring g_language = L"cpp";
std::wstring g_encoding = L"UTF-8";

bool g_coloring = false;


// ============================================================
// COLORS
// ============================================================

const COLORREF EDITOR_BG =
    RGB(255, 255, 255);

const COLORREF EDITOR_TEXT =
    RGB(30, 30, 30);

const COLORREF KEYWORD_COLOR =
    RGB(0, 90, 180);

const COLORREF STRING_COLOR =
    RGB(160, 70, 20);

const COLORREF COMMENT_COLOR =
    RGB(0, 130, 60);

const COLORREF NUMBER_COLOR =
    RGB(130, 70, 160);

const COLORREF PREPROCESSOR_COLOR =
    RGB(150, 70, 150);

const COLORREF OUTPUT_BG =
    RGB(245, 245, 245);


// ============================================================
// UTF-8
// ============================================================

std::wstring UTF8ToWide(
    const std::string& text
)
{
    if (text.empty())
        return L"";

    int size =
        MultiByteToWideChar(
            CP_UTF8,
            0,
            text.data(),
            (int)text.size(),
            nullptr,
            0
        );

    if (size <= 0)
        return L"";

    std::wstring result(
        size,
        L'\0'
    );

    MultiByteToWideChar(
        CP_UTF8,
        0,
        text.data(),
        (int)text.size(),
        result.data(),
        size
    );

    return result;
}


std::string WideToUTF8(
    const std::wstring& text
)
{
    if (text.empty())
        return "";

    int size =
        WideCharToMultiByte(
            CP_UTF8,
            0,
            text.data(),
            (int)text.size(),
            nullptr,
            0,
            nullptr,
            nullptr
        );

    if (size <= 0)
        return "";

    std::string result(
        size,
        '\0'
    );

    WideCharToMultiByte(
        CP_UTF8,
        0,
        text.data(),
        (int)text.size(),
        result.data(),
        size,
        nullptr,
        nullptr
    );

    return result;
}


// ============================================================
// ANSI
// ============================================================

std::wstring ANSIToWide(
    const std::string& text
)
{
    if (text.empty())
        return L"";

    int size =
        MultiByteToWideChar(
            CP_ACP,
            0,
            text.data(),
            (int)text.size(),
            nullptr,
            0
        );

    if (size <= 0)
        return L"";

    std::wstring result(
        size,
        L'\0'
    );

    MultiByteToWideChar(
        CP_ACP,
        0,
        text.data(),
        (int)text.size(),
        result.data(),
        size
    );

    return result;
}


std::string WideToANSI(
    const std::wstring& text
)
{
    if (text.empty())
        return "";

    int size =
        WideCharToMultiByte(
            CP_ACP,
            0,
            text.data(),
            (int)text.size(),
            nullptr,
            0,
            nullptr,
            nullptr
        );

    if (size <= 0)
        return "";

    std::string result(
        size,
        '\0'
    );

    WideCharToMultiByte(
        CP_ACP,
        0,
        text.data(),
        (int)text.size(),
        result.data(),
        size,
        nullptr,
        nullptr
    );

    return result;
}


// ============================================================
// PATH
// ============================================================

std::string PathToUTF8(
    const std::wstring& path
)
{
    return WideToUTF8(path);
}


// ============================================================
// EDITOR TEXT
// ============================================================

std::wstring GetEditorText()
{
    int length =
        GetWindowTextLengthW(
            g_editor
        );

    if (length <= 0)
        return L"";

    std::wstring text(
        length + 1,
        L'\0'
    );

    GetWindowTextW(
        g_editor,
        text.data(),
        length + 1
    );

    text.resize(length);

    return text;
}


void SetEditorText(
    const std::wstring& text
)
{
    SetWindowTextW(
        g_editor,
        text.c_str()
    );
}


// ============================================================
// OUTPUT
// ============================================================

void Output(
    const std::wstring& text
)
{
    SetWindowTextW(
        g_output,
        text.c_str()
    );
}


// ============================================================
// STATUS
// ============================================================

void UpdateStatus()
{
    std::wstring text =
        L"  Language: " +
        g_language +
        L"    |    Encoding: " +
        g_encoding;

    if (!g_file.empty())
    {
        text +=
            L"    |    " +
            g_file;
    }

    SetWindowTextW(
        g_status,
        text.c_str()
    );
}


// ============================================================
// TEMPLATES
// ============================================================

std::wstring CTemplate()
{
    return
        L"#include <stdio.h>\r\n"
        L"\r\n"
        L"int main()\r\n"
        L"{\r\n"
        L"    printf(\"Hello from Code++!\\n\");\r\n"
        L"    return 0;\r\n"
        L"}\r\n";
}


std::wstring CPPTemplate()
{
    return
        L"#include <iostream>\r\n"
        L"\r\n"
        L"int main()\r\n"
        L"{\r\n"
        L"    std::cout << \"Hello from Code++!\" << std::endl;\r\n"
        L"    return 0;\r\n"
        L"}\r\n";
}


std::wstring PythonTemplate()
{
    return
        L"print(\"Hello from Code++!\")\r\n"
        L"\r\n"
        L"for i in range(5):\r\n"
        L"    print(\"Count:\", i + 1)\r\n";
}


std::wstring TextTemplate()
{
    return
        L"Code++\r\n"
        L"\r\n";
}


// ============================================================
// NEW FILE
// ============================================================

void NewFile(
    const std::wstring& type
)
{
    g_file.clear();

    if (type == L"c")
    {
        g_language = L"c";

        SetEditorText(
            CTemplate()
        );
    }
    else if (type == L"cpp")
    {
        g_language = L"cpp";

        SetEditorText(
            CPPTemplate()
        );
    }
    else if (type == L"python")
    {
        g_language = L"python";

        SetEditorText(
            PythonTemplate()
        );
    }
    else
    {
        g_language = L"text";

        SetEditorText(
            TextTemplate()
        );
    }

    UpdateStatus();

    Output(
        L"========== NEW FILE ==========\r\n"
        L"New document created.\r\n"
    );

    SetTimer(
        g_main,
        ID_TIMER_COLOR,
        100,
        nullptr
    );
}


// ============================================================
// SAVE FILTER
// ============================================================

const wchar_t* SaveFilter()
{
    return
        L"C File (*.c)\0"
        L"*.c\0"

        L"C++ File (*.cpp)\0"
        L"*.cpp\0"

        L"Python File (*.py)\0"
        L"*.py\0"

        L"Text File (*.txt)\0"
        L"*.txt\0"

        L"All Files\0"
        L"*.*\0"

        L"\0";
}


// ============================================================
// CHECK EXTENSION
// ============================================================

bool HasExtension(
    const std::wstring& filename
)
{
    size_t slash =
        filename.find_last_of(
            L"\\/");

    size_t dot =
        filename.find_last_of(
            L'.');

    if (dot == std::wstring::npos)
        return false;

    if (
        slash != std::wstring::npos &&
        dot < slash
    )
        return false;

    return true;
}


bool CheckSaveExtension(
    const std::wstring& filename,
    DWORD filterIndex
)
{
    // All Files: đuôi gì cũng được,
    // nhưng vẫn phải có đuôi.
    if (filterIndex == 5)
    {
        if (!HasExtension(filename))
        {
            MessageBoxW(
                g_main,
                L"Hay tu nhap duoi file.\r\n"
                L"Vi du: test.xyz",
                L"Code++ - Save As",
                MB_OK |
                MB_ICONWARNING
            );

            return false;
        }

        return true;
    }

    if (!HasExtension(filename))
    {
        const wchar_t* typeName =
            L"";

        switch (filterIndex)
        {
            case 1:
                typeName =
                    L".c";
                break;

            case 2:
                typeName =
                    L".cpp";
                break;

            case 3:
                typeName =
                    L".py";
                break;

            case 4:
                typeName =
                    L".txt";
                break;
        }

        std::wstring message =
            L"Ban chua nhap duoi file.\r\n\r\n"
            L"Hay nhap duoi ";

        message +=
            typeName;

        message +=
            L" thu cong.\r\n\r\n"
            L"Vi du: test";

        message +=
            typeName;

        MessageBoxW(
            g_main,
            message.c_str(),
            L"Code++ - Save As",
            MB_OK |
            MB_ICONWARNING
        );

        return false;
    }

    return true;
}


// ============================================================
// SAVE
// ============================================================

bool SaveToFile(
    const std::wstring& filename
)
{
    std::wstring text =
        GetEditorText();

    std::string data;

    if (g_encoding == L"UTF-8")
        data = WideToUTF8(text);
    else
        data = WideToANSI(text);

    std::ofstream file(
        PathToUTF8(filename),
        std::ios::binary
    );

    if (!file)
        return false;

    file.write(
        data.data(),
        (std::streamsize)data.size()
    );

    file.close();

    return true;
}


// ============================================================
// LANGUAGE FROM EXTENSION
// ============================================================

void DetectLanguage(
    const std::wstring& filename
)
{
    size_t dot =
        filename.find_last_of(L'.');

    if (dot == std::wstring::npos)
    {
        g_language = L"text";
        return;
    }

    std::wstring ext =
        filename.substr(dot);

    std::transform(
        ext.begin(),
        ext.end(),
        ext.begin(),
        towlower
    );

    if (ext == L".c")
        g_language = L"c";

    else if (
        ext == L".cpp" ||
        ext == L".cc" ||
        ext == L".cxx"
    )
        g_language = L"cpp";

    else if (ext == L".py")
        g_language = L"python";

    else
        g_language = L"text";
}


// ============================================================
// SAVE AS
// ============================================================

bool SaveAs()
{
    wchar_t filename[MAX_PATH] =
        L"";

    OPENFILENAMEW ofn = {};

    ofn.lStructSize =
        sizeof(ofn);

    ofn.hwndOwner =
        g_main;

    ofn.lpstrFilter =
        SaveFilter();

    ofn.lpstrFile =
        filename;

    ofn.nMaxFile =
        MAX_PATH;

    ofn.Flags =
        OFN_OVERWRITEPROMPT |
        OFN_PATHMUSTEXIST;

    // Không tự động thêm extension.
    ofn.lpstrDefExt =
        nullptr;

    // C++ mặc định.
    ofn.nFilterIndex =
        2;

    if (!GetSaveFileNameW(&ofn))
        return false;

    // Người dùng bắt buộc phải tự nhập đuôi.
    if (!CheckSaveExtension(
            filename,
            ofn.nFilterIndex))
    {
        return false;
    }

    g_file =
        filename;

    if (!SaveToFile(g_file))
    {
        MessageBoxW(
            g_main,
            L"Khong the luu file.",
            L"Code++",
            MB_ICONERROR
        );

        return false;
    }

    DetectLanguage(
        g_file
    );

    UpdateStatus();

    Output(
        L"========== SAVE ==========\r\n"
        L"Saved:\r\n" +
        g_file +
        L"\r\n"
    );

    SetTimer(
        g_main,
        ID_TIMER_COLOR,
        50,
        nullptr
    );

    return true;
}


// ============================================================
// SAVE
// ============================================================

bool Save()
{
    if (g_file.empty())
        return SaveAs();

    if (!SaveToFile(g_file))
    {
        MessageBoxW(
            g_main,
            L"Khong the luu file.",
            L"Code++",
            MB_ICONERROR
        );

        return false;
    }

    UpdateStatus();

    Output(
        L"========== SAVE ==========\r\n"
        L"Saved:\r\n" +
        g_file +
        L"\r\n"
    );

    return true;
}


// ============================================================
// OPEN
// ============================================================

void OpenFile()
{
    wchar_t filename[MAX_PATH] =
        L"";

    OPENFILENAMEW ofn = {};

    ofn.lStructSize =
        sizeof(ofn);

    ofn.hwndOwner =
        g_main;

    ofn.lpstrFilter =
        L"C File (*.c)\0"
        L"*.c\0"

        L"C++ File (*.cpp)\0"
        L"*.cpp\0"

        L"Python File (*.py)\0"
        L"*.py\0"

        L"Text File (*.txt)\0"
        L"*.txt\0"

        L"All Files\0"
        L"*.*\0"

        L"\0";

    ofn.lpstrFile =
        filename;

    ofn.nMaxFile =
        MAX_PATH;

    ofn.Flags =
        OFN_FILEMUSTEXIST |
        OFN_PATHMUSTEXIST;

    if (!GetOpenFileNameW(&ofn))
        return;

    std::ifstream file(
        PathToUTF8(filename),
        std::ios::binary
    );

    if (!file)
    {
        MessageBoxW(
            g_main,
            L"Khong the mo file.",
            L"Code++",
            MB_ICONERROR
        );

        return;
    }

    std::string data(
        (std::istreambuf_iterator<char>(file)),
        std::istreambuf_iterator<char>()
    );

    file.close();

    // Kiểm tra UTF-8 BOM.
    if (
        data.size() >= 3 &&
        (unsigned char)data[0] == 0xEF &&
        (unsigned char)data[1] == 0xBB &&
        (unsigned char)data[2] == 0xBF
    )
    {
        data.erase(
            0,
            3
        );

        g_encoding =
            L"UTF-8";
    }

    std::wstring text;

    if (g_encoding == L"ANSI")
        text = ANSIToWide(data);
    else
        text = UTF8ToWide(data);

    SetEditorText(
        text
    );

    g_file =
        filename;

    DetectLanguage(
        g_file
    );

    UpdateStatus();

    Output(
        L"========== OPEN ==========\r\n"
        L"Opened:\r\n" +
        g_file +
        L"\r\n"
    );

    SetTimer(
        g_main,
        ID_TIMER_COLOR,
        100,
        nullptr
    );
}


// ============================================================
// LANGUAGE
// ============================================================

void SetLanguage(
    const std::wstring& lang
)
{
    g_language =
        lang;

    UpdateStatus();

    SetTimer(
        g_main,
        ID_TIMER_COLOR,
        50,
        nullptr
    );
}


// ============================================================
// WORD
// ============================================================

bool IsWordChar(
    wchar_t c
)
{
    return
        (c >= L'a' && c <= L'z') ||
        (c >= L'A' && c <= L'Z') ||
        (c >= L'0' && c <= L'9') ||
        c == L'_';
}


// ============================================================
// KEYWORDS
// ============================================================

bool IsKeyword(
    const std::wstring& word
)
{
    static const wchar_t* cpp[] =
    {
        L"int",
        L"float",
        L"double",
        L"char",
        L"bool",
        L"void",
        L"long",
        L"short",
        L"unsigned",
        L"signed",

        L"if",
        L"else",
        L"for",
        L"while",
        L"do",
        L"switch",
        L"case",
        L"default",

        L"return",
        L"break",
        L"continue",

        L"class",
        L"struct",
        L"public",
        L"private",
        L"protected",

        L"new",
        L"delete",
        L"const",
        L"static",

        L"using",
        L"namespace",

        L"true",
        L"false",
        L"nullptr",

        L"auto",

        L"include",
        L"define",

        L"std",
        L"cout",
        L"cin",
        L"endl"
    };

    static const wchar_t* python[] =
    {
        L"def",
        L"return",
        L"if",
        L"else",
        L"elif",
        L"for",
        L"while",
        L"in",

        L"import",
        L"from",
        L"as",

        L"class",

        L"try",
        L"except",
        L"finally",

        L"with",

        L"lambda",

        L"True",
        L"False",
        L"None",

        L"and",
        L"or",
        L"not",
        L"is",

        L"break",
        L"continue",
        L"pass",

        L"print"
    };

    if (g_language == L"python")
    {
        for (
            const wchar_t* keyword :
            python
        )
        {
            if (word == keyword)
                return true;
        }
    }
    else if (
        g_language == L"c" ||
        g_language == L"cpp"
    )
    {
        for (
            const wchar_t* keyword :
            cpp
        )
        {
            if (word == keyword)
                return true;
        }
    }

    return false;
}


// ============================================================
// COLOR RANGE
// ============================================================

void ColorRange(
    LONG start,
    LONG end,
    COLORREF color
)
{
    CHARRANGE range = {};

    range.cpMin =
        start;

    range.cpMax =
        end;

    SendMessageW(
        g_editor,
        EM_EXSETSEL,
        0,
        (LPARAM)&range
    );

    CHARFORMAT2W format = {};

    format.cbSize =
        sizeof(format);

    format.dwMask =
        CFM_COLOR;

    format.crTextColor =
        color;

    SendMessageW(
        g_editor,
        EM_SETCHARFORMAT,
        SCF_SELECTION,
        (LPARAM)&format
    );
}


// ============================================================
// COLORIZE
// ============================================================

void Colorize()
{
    if (g_coloring)
        return;

    g_coloring = true;

    std::wstring text =
        GetEditorText();

    CHARRANGE oldSelection = {};

    SendMessageW(
        g_editor,
        EM_EXGETSEL,
        0,
        (LPARAM)&oldSelection
    );

    ColorRange(
        0,
        (LONG)text.size(),
        EDITOR_TEXT
    );

    size_t i = 0;

    while (i < text.size())
    {
        // C/C++ comments
        if (
            (g_language == L"c" ||
             g_language == L"cpp") &&
            i + 1 < text.size() &&
            text[i] == L'/' &&
            text[i + 1] == L'/'
        )
        {
            size_t start = i;

            while (
                i < text.size() &&
                text[i] != L'\n'
            )
                i++;

            ColorRange(
                (LONG)start,
                (LONG)i,
                COMMENT_COLOR
            );

            continue;
        }

        // C/C++ block comment
        if (
            (g_language == L"c" ||
             g_language == L"cpp") &&
            i + 1 < text.size() &&
            text[i] == L'/' &&
            text[i + 1] == L'*'
        )
        {
            size_t start = i;

            i += 2;

            while (
                i + 1 < text.size() &&
                !(
                    text[i] == L'*' &&
                    text[i + 1] == L'/'
                )
            )
            {
                i++;
            }

            if (i + 1 < text.size())
                i += 2;

            ColorRange(
                (LONG)start,
                (LONG)i,
                COMMENT_COLOR
            );

            continue;
        }

        // Python comment
        if (
            g_language == L"python" &&
            text[i] == L'#'
        )
        {
            size_t start = i;

            while (
                i < text.size() &&
                text[i] != L'\n'
            )
                i++;

            ColorRange(
                (LONG)start,
                (LONG)i,
                COMMENT_COLOR
            );

            continue;
        }

        // C/C++ preprocessor
        if (
            (g_language == L"c" ||
             g_language == L"cpp") &&
            text[i] == L'#'
        )
        {
            size_t start = i;

            while (
                i < text.size() &&
                text[i] != L'\n'
            )
                i++;

            ColorRange(
                (LONG)start,
                (LONG)i,
                PREPROCESSOR_COLOR
            );

            continue;
        }

        // String
        if (
            text[i] == L'"' ||
            text[i] == L'\''
        )
        {
            wchar_t quote =
                text[i];

            size_t start =
                i;

            i++;

            while (i < text.size())
            {
                if (text[i] == L'\\')
                {
                    i += 2;
                    continue;
                }

                if (text[i] == quote)
                {
                    i++;
                    break;
                }

                i++;
            }

            ColorRange(
                (LONG)start,
                (LONG)i,
                STRING_COLOR
            );

            continue;
        }

        // Number
        if (
            text[i] >= L'0' &&
            text[i] <= L'9'
        )
        {
            size_t start =
                i;

            while (
                i < text.size() &&
                (
                    (text[i] >= L'0' &&
                     text[i] <= L'9') ||
                    text[i] == L'.'
                )
            )
            {
                i++;
            }

            ColorRange(
                (LONG)start,
                (LONG)i,
                NUMBER_COLOR
            );

            continue;
        }

        // Keyword
        if (IsWordChar(text[i]))
        {
            size_t start =
                i;

            while (
                i < text.size() &&
                IsWordChar(text[i])
            )
            {
                i++;
            }

            std::wstring word =
                text.substr(
                    start,
                    i - start
                );

            if (IsKeyword(word))
            {
                ColorRange(
                    (LONG)start,
                    (LONG)i,
                    KEYWORD_COLOR
                );
            }

            continue;
        }

        i++;
    }

    SendMessageW(
        g_editor,
        EM_EXSETSEL,
        0,
        (LPARAM)&oldSelection
    );

    g_coloring = false;
}


// ============================================================
// AUTO INDENT
// ============================================================

void AutoIndent()
{
    std::wstring text =
        GetEditorText();

    CHARRANGE selection = {};

    SendMessageW(
        g_editor,
        EM_EXGETSEL,
        0,
        (LPARAM)&selection
    );

    int pos =
        selection.cpMin;

    if (
        pos <= 0 ||
        pos > (int)text.size()
    )
        return;

    int lineStart =
        pos - 1;

    while (
        lineStart > 0 &&
        text[lineStart - 1] != L'\n'
    )
    {
        lineStart--;
    }

    std::wstring indent;

    for (
        int i = lineStart;
        i < pos;
        i++
    )
    {
        if (
            text[i] == L' ' ||
            text[i] == L'\t'
        )
        {
            indent += text[i];
        }
        else
        {
            break;
        }
    }

    std::wstring line =
        text.substr(
            lineStart,
            pos - lineStart
        );

    bool increase =
        false;

    if (
        (g_language == L"c" ||
         g_language == L"cpp") &&
        line.find(L'{') !=
        std::wstring::npos
    )
    {
        increase = true;
    }

    if (
        g_language == L"python" &&
        !line.empty() &&
        line.back() == L':'
    )
    {
        increase = true;
    }

    if (increase)
        indent += L"    ";

    SendMessageW(
        g_editor,
        EM_REPLACESEL,
        TRUE,
        (LPARAM)indent.c_str()
    );
}


// ============================================================
// MENU
// ============================================================

void CreateMenus(
    HWND hwnd
)
{
    HMENU bar =
        CreateMenu();

    // FILE
    HMENU file =
        CreatePopupMenu();

    HMENU newMenu =
        CreatePopupMenu();

    AppendMenuW(
        newMenu,
        MF_STRING,
        ID_NEW_C,
        L"C File"
    );

    AppendMenuW(
        newMenu,
        MF_STRING,
        ID_NEW_CPP,
        L"C++ File"
    );

    AppendMenuW(
        newMenu,
        MF_STRING,
        ID_NEW_PY,
        L"Python File"
    );

    AppendMenuW(
        newMenu,
        MF_STRING,
        ID_NEW_TXT,
        L"Text File"
    );

    AppendMenuW(
        newMenu,
        MF_STRING,
        ID_NEW_ALL,
        L"All Files"
    );

    AppendMenuW(
        file,
        MF_POPUP,
        (UINT_PTR)newMenu,
        L"New"
    );

    AppendMenuW(
        file,
        MF_STRING,
        ID_OPEN,
        L"Open"
    );

    AppendMenuW(
        file,
        MF_STRING,
        ID_SAVE,
        L"Save"
    );

    AppendMenuW(
        file,
        MF_STRING,
        ID_SAVE_AS,
        L"Save As"
    );

    AppendMenuW(
        file,
        MF_SEPARATOR,
        0,
        nullptr
    );

    AppendMenuW(
        file,
        MF_STRING,
        ID_EXIT,
        L"Exit"
    );

    AppendMenuW(
        bar,
        MF_POPUP,
        (UINT_PTR)file,
        L"File"
    );


    // LANGUAGE
    HMENU language =
        CreatePopupMenu();

    AppendMenuW(
        language,
        MF_STRING,
        ID_LANG_C,
        L"C"
    );

    AppendMenuW(
        language,
        MF_STRING,
        ID_LANG_CPP,
        L"C++"
    );

    AppendMenuW(
        language,
        MF_STRING,
        ID_LANG_PY,
        L"Python"
    );

    AppendMenuW(
        language,
        MF_STRING,
        ID_LANG_TEXT,
        L"Text"
    );

    AppendMenuW(
        bar,
        MF_POPUP,
        (UINT_PTR)language,
        L"Language"
    );


    // ENCODING
    HMENU encoding =
        CreatePopupMenu();

    AppendMenuW(
        encoding,
        MF_STRING,
        ID_ENCODING_UTF8,
        L"UTF-8"
    );

    AppendMenuW(
        encoding,
        MF_STRING,
        ID_ENCODING_ANSI,
        L"ANSI"
    );

    AppendMenuW(
        bar,
        MF_POPUP,
        (UINT_PTR)encoding,
        L"Encoding"
    );


    // OUTPUT
    HMENU output =
        CreatePopupMenu();

    AppendMenuW(
        output,
        MF_STRING,
        ID_OUTPUT_CLEAR,
        L"Clear"
    );

    AppendMenuW(
        bar,
        MF_POPUP,
        (UINT_PTR)output,
        L"Output"
    );


    // ABOUT
    AppendMenuW(
        bar,
        MF_STRING,
        ID_ABOUT,
        L"About"
    );

    SetMenu(
        hwnd,
        bar
    );
}


// ============================================================
// ICON
// ============================================================

HICON CreateCodeIcon()
{
    const int size = 32;

    HDC screen =
        GetDC(nullptr);

    HDC dc =
        CreateCompatibleDC(screen);

    HBITMAP bmp =
        CreateCompatibleBitmap(
            screen,
            size,
            size
        );

    HGDIOBJ old =
        SelectObject(
            dc,
            bmp
        );

    HBRUSH bg =
        CreateSolidBrush(
            RGB(35, 110, 190)
        );

    RECT rect =
        {0, 0, size, size};

    FillRect(
        dc,
        &rect,
        bg
    );

    DeleteObject(bg);

    SetBkMode(
        dc,
        TRANSPARENT
    );

    SetTextColor(
        dc,
        RGB(255, 255, 255)
    );

    HFONT font =
        CreateFontW(
            20,
            0,
            0,
            0,
            FW_BOLD,
            FALSE,
            FALSE,
            FALSE,
            DEFAULT_CHARSET,
            OUT_DEFAULT_PRECIS,
            CLIP_DEFAULT_PRECIS,
            CLEARTYPE_QUALITY,
            DEFAULT_PITCH,
            L"Segoe UI"
        );

    HFONT oldFont =
        (HFONT)SelectObject(
            dc,
            font
        );

    DrawTextW(
        dc,
        L"< >",
        -1,
        &rect,
        DT_CENTER |
        DT_VCENTER |
        DT_SINGLELINE
    );

    SelectObject(
        dc,
        oldFont
    );

    DeleteObject(font);

    SelectObject(
        dc,
        old
    );

    ICONINFO info = {};

    info.fIcon =
        TRUE;

    info.hbmColor =
        bmp;

    info.hbmMask =
        bmp;

    HICON icon =
        CreateIconIndirect(
            &info
        );

    DeleteObject(bmp);

    DeleteDC(dc);

    ReleaseDC(
        nullptr,
        screen
    );

    return icon;
}


// ============================================================
// WINDOW PROC
// ============================================================

LRESULT CALLBACK WindowProc(
    HWND hwnd,
    UINT msg,
    WPARAM wParam,
    LPARAM lParam
)
{
    switch (msg)
    {
        case WM_COMMAND:
        {
            switch (LOWORD(wParam))
            {
                // FILE
                case ID_NEW_C:
                    NewFile(L"c");
                    break;

                case ID_NEW_CPP:
                    NewFile(L"cpp");
                    break;

                case ID_NEW_PY:
                    NewFile(L"python");
                    break;

                case ID_NEW_TXT:
                    NewFile(L"text");
                    break;

                case ID_NEW_ALL:
                    NewFile(L"text");
                    break;

                case ID_OPEN:
                    OpenFile();
                    break;

                case ID_SAVE:
                    Save();
                    break;

                case ID_SAVE_AS:
                    SaveAs();
                    break;

                case ID_EXIT:
                    DestroyWindow(hwnd);
                    break;


                // LANGUAGE
                case ID_LANG_C:
                    SetLanguage(L"c");
                    break;

                case ID_LANG_CPP:
                    SetLanguage(L"cpp");
                    break;

                case ID_LANG_PY:
                    SetLanguage(L"python");
                    break;

                case ID_LANG_TEXT:
                    SetLanguage(L"text");
                    break;


                // ENCODING
                case ID_ENCODING_UTF8:
                    g_encoding =
                        L"UTF-8";

                    UpdateStatus();

                    Output(
                        L"Encoding: UTF-8\r\n"
                    );

                    break;

                case ID_ENCODING_ANSI:
                    g_encoding =
                        L"ANSI";

                    UpdateStatus();

                    Output(
                        L"Encoding: ANSI\r\n"
                    );

                    break;


                // OUTPUT
                case ID_OUTPUT_CLEAR:
                    Output(L"");
                    break;


                // ABOUT
                case ID_ABOUT:
                    MessageBoxW(
                        hwnd,
                        L"Code++ 1.0.0 beta\r\n"
                        L"\r\n"
                        L"Simple C / C++ / Python editor\r\n"
                        L"Win32 + MinGW",
                        L"About Code++",
                        MB_OK |
                        MB_ICONINFORMATION
                    );

                    break;
            }

            return 0;
        }


        // ====================================================
        // KEYBOARD
        // ====================================================

        case WM_KEYDOWN:
        {
            if (GetFocus() == g_editor)
            {
                // CTRL + S
                if (
                    (GetKeyState(VK_CONTROL) &
                     0x8000) &&
                    wParam == 'S'
                )
                {
                    Save();
                    return 0;
                }

                // CTRL + O
                if (
                    (GetKeyState(VK_CONTROL) &
                     0x8000) &&
                    wParam == 'O'
                )
                {
                    OpenFile();
                    return 0;
                }

                // CTRL + N
                if (
                    (GetKeyState(VK_CONTROL) &
                     0x8000) &&
                    wParam == 'N'
                )
                {
                    NewFile(L"cpp");
                    return 0;
                }

                // TAB
                if (wParam == VK_TAB)
                {
                    SendMessageW(
                        g_editor,
                        EM_REPLACESEL,
                        TRUE,
                        (LPARAM)L"    "
                    );

                    return 0;
                }

                // ENTER
                if (wParam == VK_RETURN)
                {
                    SendMessageW(
                        g_editor,
                        WM_CHAR,
                        VK_RETURN,
                        0
                    );

                    AutoIndent();

                    SetTimer(
                        hwnd,
                        ID_TIMER_COLOR,
                        100,
                        nullptr
                    );

                    return 0;
                }
            }

            break;
        }


        // ====================================================
        // CHARACTER INPUT
        // ====================================================

        case WM_CHAR:
        {
            if (
                GetFocus() == g_editor &&
                !g_coloring
            )
            {
                SetTimer(
                    hwnd,
                    ID_TIMER_COLOR,
                    150,
                    nullptr
                );
            }

            break;
        }


        // ====================================================
        // RESIZE
        // ====================================================

        case WM_SIZE:
        {
            int width =
                LOWORD(lParam);

            int height =
                HIWORD(lParam);

            const int outputHeight =
                180;

            const int statusHeight =
                25;

            int editorHeight =
                height -
                outputHeight -
                statusHeight;

            if (editorHeight < 50)
                editorHeight = 50;

            MoveWindow(
                g_editor,
                0,
                0,
                width,
                editorHeight,
                TRUE
            );

            MoveWindow(
                g_output,
                0,
                editorHeight,
                width,
                outputHeight,
                TRUE
            );

            MoveWindow(
                g_status,
                0,
                editorHeight +
                outputHeight,
                width,
                statusHeight,
                TRUE
            );

            return 0;
        }


        // ====================================================
        // TIMER
        // ====================================================

        case WM_TIMER:
        {
            if (
                wParam ==
                ID_TIMER_COLOR
            )
            {
                KillTimer(
                    hwnd,
                    ID_TIMER_COLOR
                );

                Colorize();
            }

            return 0;
        }


        // ====================================================
        // DESTROY
        // ====================================================

        case WM_DESTROY:
        {
            if (g_editorFont)
                DeleteObject(
                    g_editorFont
                );

            if (g_outputFont)
                DeleteObject(
                    g_outputFont
                );

            if (g_icon)
                DestroyIcon(
                    g_icon
                );

            PostQuitMessage(0);

            return 0;
        }
    }

    return DefWindowProcW(
        hwnd,
        msg,
        wParam,
        lParam
    );
}


// ============================================================
// WINMAIN
// ============================================================

int WINAPI WinMain(
    HINSTANCE hInstance,
    HINSTANCE,
    LPSTR,
    int nCmdShow
)
{
    // RichEdit
    LoadLibraryW(
        L"Msftedit.dll"
    );


    INITCOMMONCONTROLSEX icc = {};

    icc.dwSize =
        sizeof(icc);

    icc.dwICC =
        ICC_STANDARD_CLASSES;

    InitCommonControlsEx(
        &icc
    );


    const wchar_t CLASS_NAME[] =
        L"CodePlusPlusWindow";


    g_icon =
        CreateCodeIcon();


    WNDCLASSW wc = {};

    wc.lpfnWndProc =
        WindowProc;

    wc.hInstance =
        hInstance;

    wc.lpszClassName =
        CLASS_NAME;

    wc.hCursor =
        LoadCursorW(
            nullptr,
            IDC_ARROW
        );

    wc.hIcon =
        g_icon;

    wc.hbrBackground =
        (HBRUSH)(
            COLOR_WINDOW + 1
        );


    RegisterClassW(
        &wc
    );


    g_main =
        CreateWindowExW(
            0,
            CLASS_NAME,
            L"Code++",
            WS_OVERLAPPEDWINDOW,
            CW_USEDEFAULT,
            CW_USEDEFAULT,
            1100,
            720,
            nullptr,
            nullptr,
            hInstance,
            nullptr
        );

    if (!g_main)
        return 0;


    // ========================================================
    // EDITOR
    // ========================================================

    g_editor =
        CreateWindowExW(
            WS_EX_CLIENTEDGE,
            L"RICHEDIT50W",
            L"",
            WS_VISIBLE |
            WS_CHILD |
            WS_VSCROLL |
            WS_HSCROLL |
            ES_MULTILINE |
            ES_AUTOVSCROLL |
            ES_AUTOHSCROLL |
            ES_WANTRETURN,
            0,
            0,
            0,
            0,
            g_main,
            (HMENU)ID_EDITOR,
            hInstance,
            nullptr
        );


    // ========================================================
    // OUTPUT
    // ========================================================

    g_output =
        CreateWindowExW(
            WS_EX_CLIENTEDGE,
            L"EDIT",
            L"",
            WS_VISIBLE |
            WS_CHILD |
            WS_VSCROLL |
            ES_MULTILINE |
            ES_READONLY |
            ES_AUTOVSCROLL,
            0,
            0,
            0,
            0,
            g_main,
            (HMENU)ID_OUTPUT,
            hInstance,
            nullptr
        );


    // ========================================================
    // STATUS
    // ========================================================

    g_status =
        CreateWindowExW(
            0,
            L"STATIC",
            L"",
            WS_VISIBLE |
            WS_CHILD |
            SS_CENTERIMAGE,
            0,
            0,
            0,
            0,
            g_main,
            (HMENU)ID_STATUS,
            hInstance,
            nullptr
        );


    // ========================================================
    // FONT
    // ========================================================

    g_editorFont =
        CreateFontW(
            19,
            0,
            0,
            0,
            FW_NORMAL,
            FALSE,
            FALSE,
            FALSE,
            DEFAULT_CHARSET,
            OUT_DEFAULT_PRECIS,
            CLIP_DEFAULT_PRECIS,
            CLEARTYPE_QUALITY,
            FIXED_PITCH |
            FF_MODERN,
            L"Consolas"
        );


    g_outputFont =
        CreateFontW(
            16,
            0,
            0,
            0,
            FW_NORMAL,
            FALSE,
            FALSE,
            FALSE,
            DEFAULT_CHARSET,
            OUT_DEFAULT_PRECIS,
            CLIP_DEFAULT_PRECIS,
            CLEARTYPE_QUALITY,
            FIXED_PITCH |
            FF_MODERN,
            L"Consolas"
        );


    SendMessageW(
        g_editor,
        WM_SETFONT,
        (WPARAM)g_editorFont,
        TRUE
    );


    SendMessageW(
        g_output,
        WM_SETFONT,
        (WPARAM)g_outputFont,
        TRUE
    );


    // ========================================================
    // WHITE EDITOR
    // ========================================================

    SendMessageW(
        g_editor,
        EM_SETBKGNDCOLOR,
        0,
        EDITOR_BG
    );


    SendMessageW(
        g_output,
        EM_SETBKGNDCOLOR,
        0,
        OUTPUT_BG
    );


    CHARFORMAT2W format = {};

    format.cbSize =
        sizeof(format);

    format.dwMask =
        CFM_COLOR;

    format.crTextColor =
        EDITOR_TEXT;

    SendMessageW(
        g_editor,
        EM_SETCHARFORMAT,
        SCF_ALL,
        (LPARAM)&format
    );


    // ========================================================
    // MENU
    // ========================================================

    CreateMenus(
        g_main
    );


    // ========================================================
    // SHOW
    // ========================================================

    ShowWindow(
        g_main,
        nCmdShow
    );

    UpdateWindow(
        g_main
    );


    // Default document
    NewFile(
        L"cpp"
    );


    // ========================================================
    // MESSAGE LOOP
    // ========================================================

    MSG msg = {};

    while (
        GetMessageW(
            &msg,
            nullptr,
            0,
            0
        )
    )
    {
        TranslateMessage(
            &msg
        );

        DispatchMessageW(
            &msg
        );
    }

    return 0;
}